#this project use recoursion
given a matrix (NxN) this program outputs the indices of the matrix in spiral order
